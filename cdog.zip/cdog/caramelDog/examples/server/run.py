import os
os.system("./caramelcc server.cdog ")
os.system("./server")