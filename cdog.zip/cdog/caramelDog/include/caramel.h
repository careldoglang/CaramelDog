#ifndef CARAMEL_H
#define CARAMEL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ----------------- Função include para arquivos .p -----------------
static char* include(const char* filename) {
    FILE* f = fopen(filename, "r");
    if (!f) {
        fprintf(stderr, "Erro: não foi possível abrir %s\n", filename);
        return NULL;
    }

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);

    char* buffer = (char*)malloc(size + 1);
    if (!buffer) {
        fclose(f);
        fprintf(stderr, "Erro: memória insuficiente para incluir %s\n", filename);
        return NULL;
    }

    fread(buffer, 1, size, f);
    buffer[size] = '\0';
    fclose(f);

    return buffer;
}

// ----------------- Macros para classes -----------------
#define class(name) \
    typedef struct name name; \
    struct name

#define method(cls, ret_type, name, ...) \
    ret_type (*name)(cls* self, ##__VA_ARGS__)

#define init_method(cls) cls* init_##cls()
#define new(cls) init_##cls()
#define delete(obj) free(obj)

// ----------------- Herança -----------------
#define inherit(child, parent) \
    parent parent_part;

// ----------------- Métodos virtuais -----------------
#define virtual(method) method
#define override(method) method

// ----------------- Gerenciador de variáveis -----------------
typedef struct {
    const char* name;
    int access_count;
    void* ptr;
} varinfo;

#define MAX_VARS 64

typedef struct {
    varinfo vars[MAX_VARS];
    int count;
} var_manager;

static void var_manager_init(var_manager* vm) {
    vm->count = 0;
}

static void var_manager_register(var_manager* vm, const char* name, void* ptr) {
    if (vm->count >= MAX_VARS) return;
    vm->vars[vm->count].name = name;
    vm->vars[vm->count].ptr = ptr;
    vm->vars[vm->count].access_count = 0;
    vm->count++;
}

static void var_manager_access(var_manager* vm, const char* name) {
    for (int i = 0; i < vm->count; i++) {
        if (strcmp(vm->vars[i].name, name) == 0) {
            vm->vars[i].access_count++;
            break;
        }
    }
}

static void var_manager_report(var_manager* vm) {
    printf("---- Variáveis mais usadas ----\n");
    for (int i = 0; i < vm->count; i++) {
        printf("%s: %d acessos\n", vm->vars[i].name, vm->vars[i].access_count);
    }
}

static void var_manager_optimize(var_manager* vm) {
    printf("---- Otimizando variáveis ----\n");
    for (int i = 0; i < vm->count; i++) {
        if (vm->vars[i].access_count > 2) {
            printf("Variável %s recomendada para register\n", vm->vars[i].name);
        }
    }
}

#endif 
#ifndef CARAMEL_WEB_H
#define CARAMEL_WEB_H

/* caramel_web.h
 *
 * Minimal, robust-ish HTTP server library for "Cachorro Caramelo".
 * - Uses POSIX sockets and pthreads (sys/socket.h, netinet/in.h, arpa/inet.h)
 * - Multi-threaded: one thread per connection (basic)
 * - Routing, middleware, simple template support, JSON helper
 *
 * NOTE: This is intentionally self-contained (no libcurl, no external deps).
 *       For production-scale use add: thread-pool, epoll/IO_URING, caches, TLS, etc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>
#include <sys/stat.h>

#define CWEB_MAX_BUF        16384
#define CWEB_MAX_PATH       512
#define CWEB_MAX_ROUTES     128
#define CWEB_MAX_MIDDLEWARE 32
#define CWEB_MAX_HEADERS    64
#define CWEB_MAX_HEADER_LEN 1024

typedef struct {
    char key[128];
    char value[1024];
} Header;

typedef struct {
    char method[8];
    char path[CWEB_MAX_PATH];
    char raw_path[CWEB_MAX_PATH];
    char query[1024];
    Header headers[CWEB_MAX_HEADERS];
    int header_count;
    char body[CWEB_MAX_BUF];
    int body_len;
} CRequest;

typedef struct {
    int client_fd;
} CResponse;

/* handler signature */
typedef void (*croute_handler_t)(CRequest* req, CResponse* res);
typedef void (*cmiddleware_t)(CRequest* req, CResponse* res);

typedef struct {
    char path[CWEB_MAX_PATH]; /* exact match only in this version; can be extended */
    char method[8];           /* "GET", "POST" or "*" for any */
    croute_handler_t handler;
} CRoute;

typedef struct {
    int port;
    int server_fd;
    CRoute routes[CWEB_MAX_ROUTES];
    int route_count;
    cmiddleware_t middlewares[CWEB_MAX_MIDDLEWARE];
    int middleware_count;
    int backlog;
} CServer;

/* ----------- Utilities ----------- */

static void cweb_log(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    time_t t = time(NULL);
    struct tm tm;
    localtime_r(&t, &tm);
    char timestr[32];
    strftime(timestr, sizeof(timestr), "%Y-%m-%d %H:%M:%S", &tm);
    printf("[%s] ", timestr);
    vprintf(fmt, ap);
    printf("\n");
    va_end(ap);
}

static void trim_trailing_whitespace(char* s) {
    int i = strlen(s) - 1;
    while (i >= 0 && (s[i] == '\r' || s[i] == '\n' || s[i] == ' ' || s[i] == '\t')) {
        s[i] = '\0';
        i--;
    }
}

/* safe write all */
static ssize_t write_all(int fd, const void* buf, size_t count) {
    const char* p = buf;
    size_t left = count;
    while (left > 0) {
        ssize_t w = write(fd, p, left);
        if (w <= 0) return w;
        p += w; left -= w;
    }
    return count;
}

/* URL-decode minimal */
static void url_decode(char* dst, const char* src) {
    char a, b;
    while (*src) {
        if ((*src == '%') && ((a = src[1]) && (b = src[2])) && (isxdigit(a) && isxdigit(b))) {
            char hex[3] = {a, b, 0};
            *dst++ = (char) strtol(hex, NULL, 16);
            src += 3;
        } else if (*src == '+') {
            *dst++ = ' ';
            src++;
        } else {
            *dst++ = *src++;
        }
    }
    *dst = '\0';
}

/* get header (case-insensitive) */
static const char* crequest_get_header(CRequest* req, const char* key) {
    for (int i=0;i<req->header_count;i++) {
        if (strcasecmp(req->headers[i].key, key) == 0) return req->headers[i].value;
    }
    return NULL;
}

/* get query param by name (first match) */
static int crequest_get_query_param(CRequest* req, const char* name, char* out, int outlen) {
    if (!req->query || !req->query[0]) return 0;
    char qdup[1024]; strncpy(qdup, req->query, sizeof(qdup)-1);
    char* token = strtok(qdup, "&");
    while (token) {
        char* eq = strchr(token, '=');
        if (eq) {
            *eq = '\0';
            char* k = token;
            char* v = eq+1;
            if (strcmp(k, name) == 0) {
                url_decode(out, v);
                return 1;
            }
        } else {
            if (strcmp(token, name) == 0) { out[0]='\0'; return 1; }
        }
        token = strtok(NULL, "&");
    }
    return 0;
}

/* ----------- Response helpers ----------- */

static void cresponse_send_text(CResponse* res, const char* body) {
    char header[256];
    snprintf(header, sizeof(header),
             "HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
             strlen(body));
    write_all(res->client_fd, header, strlen(header));
    write_all(res->client_fd, body, strlen(body));
}

static void cresponse_send_status(CResponse* res, int status, const char* status_text, const char* body) {
    char header[256];
    snprintf(header, sizeof(header),
             "HTTP/1.1 %d %s\r\nContent-Type: text/plain\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
             status, status_text, strlen(body));
    write_all(res->client_fd, header, strlen(header));
    write_all(res->client_fd, body, strlen(body));
}

static void cresponse_send_json(CResponse* res, const char* json_body) {
    char header[256];
    snprintf(header, sizeof(header),
             "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
             strlen(json_body));
    write_all(res->client_fd, header, strlen(header));
    write_all(res->client_fd, json_body, strlen(json_body));
}

static void cresponse_send_file(CResponse* res, const char* filepath) {
    struct stat st;
    if (stat(filepath, &st) != 0) {
        cresponse_send_status(res, 404, "Not Found", "404 Not Found");
        return;
    }
    FILE* f = fopen(filepath, "rb");
    if (!f) { cresponse_send_status(res, 500, "IO Error", "500"); return; }
    size_t size = st.st_size;
    char header[256];
    snprintf(header, sizeof(header),
             "HTTP/1.1 200 OK\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n", size);
    write_all(res->client_fd, header, strlen(header));
    char buf[4096];
    size_t r;
    while ((r = fread(buf,1,sizeof(buf),f)) > 0) write_all(res->client_fd, buf, r);
    fclose(f);
}

/* simple JSON builder helpers (tiny): create object like {"k":"v"} by formatting */
static void json_escape_simple(const char* in, char* out, int outlen) {
    int j=0;
    for (int i=0; in[i] && j+1<outlen; i++) {
        char c = in[i];
        if (c == '"' || c=='\\') { if (j+2 < outlen) { out[j++]='\\'; out[j++]=c; } }
        else if (c == '\n') { if (j+2 < outlen) { out[j++]='\\'; out[j++]='n'; } }
        else out[j++]=c;
    }
    out[j]='\0';
}

/* ----------- Request parsing ----------- */

/* parse request line + headers (very tolerant) */
static void parse_http_request(char* raw, CRequest* req) {
    memset(req, 0, sizeof(CRequest));
    req->header_count = 0;
    req->body_len = 0;

    char* p = raw;
    /* request line */
    char method[16], pathfull[1024];
    if (sscanf(p, "%15s %1023s", method, pathfull) != 2) {
        strncpy(req->method, "GET", sizeof(req->method)-1);
        strcpy(req->path, "/");
        return;
    }
    strncpy(req->method, method, sizeof(req->method)-1);
    /* split path and query */
    char* qpos = strchr(pathfull, '?');
    if (qpos) {
        size_t pathlen = qpos - pathfull;
        if (pathlen >= sizeof(req->path)) pathlen = sizeof(req->path)-1;
        strncpy(req->path, pathfull, pathlen);
        req->path[pathlen]='\0';
        strncpy(req->query, qpos+1, sizeof(req->query)-1);
    } else {
        strncpy(req->path, pathfull, sizeof(req->path)-1);
        req->query[0]='\0';
    }
    strncpy(req->raw_path, req->path, sizeof(req->raw_path)-1);

    /* move p to line after request line */
    char* line = strchr(p, '\n');
    if (!line) return;
    p = line + 1;

    /* headers */
    while (*p && !(p[0] == '\r' && p[1] == '\n')) {
        char header_line[1024] = {0};
        char* nxt = strchr(p, '\n');
        if (!nxt) { strncpy(header_line, p, sizeof(header_line)-1); p += strlen(p); break;}
        size_t len = nxt - p;
        if (len >= sizeof(header_line)) len = sizeof(header_line)-1;
        strncpy(header_line, p, len);
        trim_trailing_whitespace(header_line);

        char* colon = strchr(header_line, ':');
        if (colon) {
            *colon = '\0';
            char* key = header_line;
            char* val = colon+1;
            while (*val == ' ') val++;
            if (req->header_count < CWEB_MAX_HEADERS) {
                strncpy(req->headers[req->header_count].key, key, sizeof(req->headers[req->header_count].key)-1);
                strncpy(req->headers[req->header_count].value, val, sizeof(req->headers[req->header_count].value)-1);
                req->header_count++;
            }
        }
        p = nxt + 1;
    }

    /* body (after \r\n\r\n) */
    char* body_start = strstr(raw, "\r\n\r\n");
    if (body_start) {
        body_start += 4;
        size_t blen = strlen(body_start);
        if (blen > sizeof(req->body)-1) blen = sizeof(req->body)-1;
        memcpy(req->body, body_start, blen);
        req->body[blen] = '\0';
        req->body_len = blen;
    }
}

/* ----------- Thread handling ----------- */

typedef struct {
    int client_fd;
    CServer* server;
} client_thread_arg_t;

static void* cweb_client_thread(void* arg) {
    client_thread_arg_t* ta = (client_thread_arg_t*)arg;
    int client_fd = ta->client_fd;
    CServer* server = ta->server;
    free(arg);

    char raw[CWEB_MAX_BUF];
    ssize_t r = read(client_fd, raw, sizeof(raw)-1);
    if (r <= 0) { close(client_fd); return NULL; }
    raw[r] = '\0';

    CRequest req;
    CResponse res;
    res.client_fd = client_fd;
    parse_http_request(raw, &req);

    cweb_log("%s %s", req.method, req.path);

    /* run middleware chain */
    for (int i=0;i<server->middleware_count;i++) {
        server->middlewares[i](&req, &res);
    }

    /* route dispatch (exact match) */
    int matched = 0;
    for (int i=0;i<server->route_count;i++) {
        if ((strcmp(server->routes[i].path, req.path) == 0 || strcmp(server->routes[i].path, "*") == 0) &&
            (strcmp(server->routes[i].method, "*") == 0 || strcmp(server->routes[i].method, req.method) == 0)) {
            server->routes[i].handler(&req, &res);
            matched = 1;
            break;
        }
    }
    if (!matched) {
        cresponse_send_status(&res, 404, "Not Found", "404 Not Found");
    }

    close(client_fd);
    return NULL;
}

/* ----------- Server API ----------- */

static CServer* start_server(int port) {
    CServer* s = (CServer*)malloc(sizeof(CServer));
    if (!s) return NULL;
    s->port = port;
    s->route_count = 0;
    s->middleware_count = 0;
    s->backlog = 128;

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) { perror("socket"); free(s); return NULL; }

    int opt = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind"); close(sock); free(s); return NULL;
    }
    if (listen(sock, s->backlog) < 0) { perror("listen"); close(sock); free(s); return NULL; }

    s->server_fd = sock;
    cweb_log("Cachorro Caramelo server started on port %d", port);
    return s;
}

static void add_route(CServer* s, const char* method, const char* path, croute_handler_t handler) {
    if (!s || s->route_count >= CWEB_MAX_ROUTES) return;
    strncpy(s->routes[s->route_count].method, method, sizeof(s->routes[s->route_count].method)-1);
    strncpy(s->routes[s->route_count].path, path, sizeof(s->routes[s->route_count].path)-1);
    s->routes[s->route_count].handler = handler;
    s->route_count++;
}

static void add_middleware(CServer* s, cmiddleware_t m) {
    if (!s || s->middleware_count >= CWEB_MAX_MIDDLEWARE) return;
    s->middlewares[s->middleware_count++] = m;
}

static void run_server(CServer* s) {
    if (!s) return;
    while (1) {
        struct sockaddr_in client_addr;
        socklen_t alen = sizeof(client_addr);
        int client_fd = accept(s->server_fd, (struct sockaddr*)&client_addr, &alen);
        if (client_fd < 0) { perror("accept"); continue; }
        client_thread_arg_t* ta = malloc(sizeof(client_thread_arg_t));
        ta->client_fd = client_fd;
        ta->server = s;
        pthread_t tid;
        pthread_create(&tid, NULL, cweb_client_thread, ta);
        pthread_detach(tid);
    }
}

/* ----------- Tiny Template helper -----------
   Replace occurrences of {key} in template with value.
   Usage: char out[...] ; cweb_render_template(template, "{name}", "Alice", out, sizeof(out));
*/
static void cweb_render_template(const char* tmpl, const char* placeholder, const char* value, char* out, int outlen) {
    out[0]='\0';
    const char* p = tmpl;
    while (*p && (int)strlen(out) + 1 < outlen) {
        const char* pos = strstr(p, placeholder);
        if (!pos) {
            strncat(out, p, outlen - strlen(out) - 1);
            break;
        }
        int chunk = pos - p;
        if (chunk > 0) strncat(out, p, (outlen - strlen(out) - 1) < chunk ? (outlen-strlen(out)-1) : chunk);
        strncat(out, value, outlen - strlen(out) - 1);
        p = pos + strlen(placeholder);
    }
}

/* ----------- Convenience macro-like wrappers for "Cachorro Caramelo" preprocessor
   Expose names that map easily:
   - start_server -> start_server
   - add_route(server, "GET", "/x", handler) -> add_route(...)
   - add_middleware(server, mw) -> add_middleware(...)
   - run_server(server) -> run_server(server)
*/

#endif /* CARAMEL_WEB_H */
