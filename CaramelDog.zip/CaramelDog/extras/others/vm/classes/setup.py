from setuptools import setup, find_packages

setup(
    name="pyclas",
    version="0.1.0",
    author="caleb",
    author_email="calebdiaspereira@gmail.com",
    description="Builder and executor for Classes VM (.clas) code — a minimalist bytecode virtual machine.",
    license="MIT",

    # pacotes Python
    packages=find_packages(where="etc"),  # procura por pyclas e src dentro de etc/
    package_dir={"": "etc"},  # diz que todos os pacotes estão dentro de etc/
    include_package_data=True,
    python_requires=">=3.8",

    install_requires=[
        "numpy>=1.25.0",
    ],

    entry_points={
        "console_scripts": [
            "classes=classes:main",  # comando CLI chamando main() de classes.py
        ],
    },

    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Interpreters",
    ],
)