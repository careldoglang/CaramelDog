import pyclas as pyclasses

pyclasses.var("x", 72)
pyclasses.mov("x")
pyclasses.print_char()
pyclasses.run("myprogram.clas")