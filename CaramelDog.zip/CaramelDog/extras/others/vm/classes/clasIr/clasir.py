# pyclasses_ir.py
from pyclas import *
class IRInstruction:
    def __init__(self, op, *args):
        self.op = op
        self.args = args

class IRBuilder:
    def __init__(self):
        self.instructions = []

    # --- Emit instruction ---
    def emit(self, op, *args):
        self.instructions.append(IRInstruction(op, *args))

    # --- Convenience methods for VM commands ---
    def var(self, name, value=0): self.emit("var", name, value)
    def mov(self, name): self.emit("mov", name)
    def ptr(self, index): self.emit("ptr", index)
    def ptr_inc(self): self.emit("ptr_inc")
    def ptr_dec(self): self.emit("ptr_dec")
    def print_val(self): self.emit("print_val")
    def print_char(self): self.emit("print_char")
    def input_val(self): self.emit("input_val")
    def reset_regs(self): self.emit("reset_regs")
    def reset_all(self): self.emit("reset_all")
    def file_read(self, filename): self.emit("file_read", filename)
    def file_delete(self, filename): self.emit("file_delete", filename)
    def add(self): self.emit("add")
    def sub(self): self.emit("sub")
    def mul(self): self.emit("mul")
    def div(self): self.emit("div")
    def idiv(self): self.emit("idiv")
    def block_start(self): self.emit("block_start")
    def block_end(self): self.emit("block_end")
    def loop_start(self): self.emit("loop_start")
    def loop_end(self): self.emit("loop_end")
    def cond_skip_zero(self): self.emit("cond_skip_zero")
    def cond_skip_nonzero(self): self.emit("cond_skip_nonzero")

    # --- Convert IR to VM code ---
    def to_vm_code(self):
        from pyclasses import code_buffer
        code_buffer.clear()
        for instr in self.instructions:
            op, args = instr.op, instr.args
            if op == "var": var(args[0], args[1])
            elif op == "mov": mov(args[0])
            elif op == "ptr": ptr_set(args[0])
            elif op == "ptr_inc": ptr_inc()
            elif op == "ptr_dec": ptr_dec()
            elif op == "print_val": print_val()
            elif op == "print_char": print_char()
            elif op == "input_val": input_val()
            elif op == "reset_regs": reset_regs()
            elif op == "reset_all": reset_all()
            elif op == "file_read": file_read(args[0])
            elif op == "file_delete": file_delete(args[0])
            elif op == "add": add()
            elif op == "sub": sub()
            elif op == "mul": mul()
            elif op == "div": div()
            elif op == "idiv": idiv()
            elif op == "block_start": block_start()
            elif op == "block_end": block_end()
            elif op == "loop_start": loop_start()
            elif op == "loop_end": loop_end()
            elif op == "cond_skip_zero": cond_skip_zero()
            elif op == "cond_skip_nonzero": cond_skip_nonzero()
        return "".join(code_buffer)

    # --- Save VM code to file ---
    def save(self, filename):
        vm_code = self.to_vm_code()
        with open(filename, "w", encoding="utf-8") as f:
            f.write(vm_code)
        return vm_code