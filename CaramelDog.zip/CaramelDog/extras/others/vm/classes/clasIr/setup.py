from setuptools import setup

setup(
    name="clasir",
    version="0.1.0",
    author="caleb",
    author_email="calebdiaspereira@gmail.com",
    py_modules=["clasir"],
    python_requires=">=3.8",
)