# pyclasses.py
import os

# === Internal VM State ===
Ast = ""
Bxc = []   # variable names
Bxd = []   # variable values
regs = [0] * 8
ptr = 0
code_buffer = []

# === Helper Functions ===
def gv(name):
    return Bxd[Bxc.index(name)] if name in Bxc else 0

def sv(name, value):
    if name in Bxc:
        Bxd[Bxc.index(name)] = value
    else:
        Bxc.append(name)
        Bxd.append(value)

def add_code(s):
    code_buffer.append(s)

# === VM Command Builder Functions ===
def var(name, value=0): add_code(f"&& {name} {value}")
def mov(name): add_code(f"&&> {name}")
def ptr_set(index):
    global ptr
    if index == 7: add_code(">")
    elif index == 0: add_code("<")
    elif index > ptr: add_code(">" * (index - ptr))
    elif index < ptr: add_code("<" * (ptr - index))
def ptr_inc(): add_code(">>")
def ptr_dec(): add_code("<<")
def print_val(): add_code(".")
def print_char(): add_code(":")
def input_val(): add_code(",")
def reset_regs(): add_code("?")
def reset_all(): add_code(",,")
def file_read(filename): add_code(f".. {filename}")
def file_delete(filename): add_code(f"!e {filename}")
def add(): add_code("+")
def sub(): add_code("-")
def mul(): add_code("*")
def div(): add_code("/")
def idiv(): add_code("\\")
def block_start(): add_code("{")
def block_end(): add_code("}")
def loop_start(): add_code("[")
def loop_end(): add_code("]")
def cond_skip_zero(): add_code("(")
def cond_skip_nonzero(): add_code(")(")

# === Run Function ===
def run(filename=None):
    """Generate VM code and optionally execute a .clas file"""
    global ptr, regs, Bxc, Bxd, Ast

    vm_code = " ".join(code_buffer)

    # Se quiser gravar num arquivo
    if filename:
        with open(filename, "w", encoding="utf-8") as f:
            f.write(vm_code)
        print(f"Code written to {filename}")

    # === Execução do código ===
    i = 0
    stack = []
    loop = []
    lines = [l.strip() for l in vm_code.splitlines() if l.strip() and not l.strip().startswith("//")]
    c = " ".join(lines)

    while i < len(c):
        s = c[i:i+3]
        s2 = c[i:i+2]

        if s2 == '>>':
            ptr = min(ptr + 1, 7)
            i += 1
        elif s2 == '<<':
            ptr = max(ptr - 1, 0)
            i += 1
        elif s == '&&>':
            i += 3
            p = c[i:].split()
            regs[ptr] = gv(p[0])
            i += len(p[0])
        elif s2 == '&&':
            i += 3
            p = c[i:].split()
            sv(p[0], int(p[1]))
            regs[ptr] = int(p[1])
            i += len(p[0]) + len(p[1])
        elif c[i] == '>':
            ptr = 7
        elif c[i] == '<':
            ptr = 0
        elif c[i] == '.':
            print(regs[ptr])
        elif c[i] == ':':
            print(chr(regs[ptr]), end="")
        elif c[i] == ',':
            regs[ptr] = int(input())
        elif s2 == ',,':
            regs = [0] * 8
            Bxc = []
            Bxd = []
            i += 1
        elif c[i] == '?':
            regs = [0] * 8
        elif s2 == '..':
            i += 1
            f = c[i:].split()[0]
            if os.path.exists(f):
                with open(f, "r", encoding="utf-8") as file:
                    content = file.read()
                for ch in content:
                    regs[ptr] = ord(ch)
                    print(chr(regs[ptr]), end="")
            i += len(f)
        elif s2 == '!e':
            i += 1
            f = c[i:].split()[0]
            if os.path.exists(f):
                os.remove(f)
        elif c[i] in '+-*/\\':
            if ptr > 0:
                regs[ptr] = eval(f"{regs[ptr-1]}{c[i].replace('\\','//')}{regs[ptr]}")
        elif c[i] == '{':
            stack.append(i)
        elif c[i] == '}':
            if stack: stack.pop()
        elif c[i] == '[':
            loop.append(i)
        elif c[i] == ']':
            if regs[3] != 0:
                i = loop[-1] - 1
            else:
                loop.pop()
        elif c[i] == '(':
            if regs[3] == 0:
                i += 1
        elif s2 == ')(':
            if regs[3] != 0:
                i += 2
        i += 1

    Ast = ""
    code_buffer.clear()
    ptr = 0
    regs = [0] * 8
    Bxc = []
    Bxd = []