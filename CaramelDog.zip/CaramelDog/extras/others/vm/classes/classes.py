Ast=""
Bxc=[];Bxd=[]
regs=[0]*8;ptr=0
import os,sys
def gv(n): return Bxd[Bxc.index(n)] if n in Bxc else 0
def sv(n,v):
    if n in Bxc: Bxd[Bxc.index(n)]=v
    else: Bxc.append(n); Bxd.append(v)
def run(c):
    global ptr,regs,Bxc,Bxd
    i=0;stack=[];loop=[]
    lines=[l.strip() for l in c.splitlines() if l.strip() and not l.strip().startswith("//")]
    c=" ".join(lines)
    while i<len(c):
        s=c[i:i+3]
        s2=c[i:i+2]
        if s2=='>>': ptr=min(ptr+1,7);i+=1
        elif s2=='<<': ptr=max(ptr-1,0);i+=1
        elif s=='&&>':
            i+=3;p=c[i:].split(); regs[ptr]=gv(p[0]); i+=len(p[0])
        elif s2=='&&':
            i+=3;p=c[i:].split(); sv(p[0],int(p[1])); regs[ptr]=int(p[1]); i+=len(p[0])+len(p[1])
        elif c[i]=='>': ptr=7
        elif c[i]=='<': ptr=0
        elif c[i]=='.': print(regs[ptr])
        elif c[i]==':': print(chr(regs[ptr]), end="")
        elif c[i]==',': regs[ptr]=int(input())
        elif s2==',,': regs=[0]*8;Bxc=[];Bxd=[];i+=1
        elif c[i]=='?': regs=[0]*8
        elif s2=='..':
            i+=1
            f=c[i:].split()[0]
            if os.path.exists(f):
                with open(f,"r",encoding="utf-8") as file:
                    content=file.read()
                for idx,ch in enumerate(content):
                    regs[ptr]=ord(ch)
                    print(chr(regs[ptr]), end="")
            i+=len(f)
        elif s2=='!e': i+=1; f=c[i:].split()[0]; os.path.exists(f) and os.remove(f)
        elif c[i] in '+-*/\\': regs[ptr]=eval(f"{regs[ptr-1]}{c[i].replace('\\','//')}{regs[ptr]}") if ptr>0 else regs[ptr]
        elif c[i]=='{': stack.append(i)
        elif c[i]=='}': stack.pop() if stack else None
        elif c[i]=='[': loop.append(i)
        elif c[i]==']': i=loop[-1]-1 if regs[3]!=0 else loop.pop()
        elif c[i]=='(': i=i+1 if regs[3]==0 else i
        elif s2==')(': i=i+2 if regs[3]!=0 else i
        i+=1
    Ast=""

def main():
    if len(sys.argv) < 2:
        print("Uso: classes <arquivo.clas>")
        return

    filename = sys.argv[1]
    if not filename.endswith(".clas"):
        filename += ".clas"

    if not os.path.exists(filename):
        print(f"Erro: arquivo '{filename}' não encontrado.")
        return

    with open(filename, "r", encoding="utf-8") as file:
        code = file.read()
    run(code)


if __name__ == "__main__":
    main()