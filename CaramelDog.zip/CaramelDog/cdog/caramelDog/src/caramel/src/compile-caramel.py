import os
os.system("gcc caramel.c -o caramel")
