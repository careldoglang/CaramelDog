import os
os.system("./caramelcc examples/example2.cdog")
os.system("./examples/example2")