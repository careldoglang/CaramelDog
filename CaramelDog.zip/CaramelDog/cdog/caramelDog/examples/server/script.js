function runCode() {
  const input = document.getElementById("code").value.trim();
  const lines = input.split("\n");
  const outputEl = document.getElementById("output");
  let output = "";

  for (let line of lines) {
    const [cmd, ...args] = line.split(" ");
    switch (cmd) {
      case "print":
        output += args.join(" ") + "\n";
        break;
      case "add":
        output += Number(args[0]) + Number(args[1]) + "\n";
        break;
      case "sub":
        output += Number(args[0]) - Number(args[1]) + "\n";
        break;
      case "mul":
        output += Number(args[0]) * Number(args[1]) + "\n";
        break;
      case "div":
        output += Number(args[0]) / Number(args[1]) + "\n";
        break;
      default:
        if (cmd.trim() !== "")
          output += `Erro: comando desconhecido '${cmd}'\n`;
    }
  }

  outputEl.textContent = output;
}