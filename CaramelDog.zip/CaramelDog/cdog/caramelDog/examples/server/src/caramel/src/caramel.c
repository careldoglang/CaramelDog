#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct {
    const char* custom;
    const char* normal;
} Keyword;

Keyword keywords[] = {
    {"if", "if"}, {"else", "else"}, {"loop", "for"}, {"ret", "return"},
    {"jump", "goto"}, {"construct", "struct"}, {"num", "int"}, {"str", "char*"},
    {"none", "void"}, {"func", "void"}, {"var", "auto"}, {"pause", "break"},
    {"ifcase", "case"}, {"const", "const"}, {"run", "continue"}, {"default", "default"},
    {"do", "do"}, {"decimal", "double"}, {"enum", "enum"}, {"extern", "extern"},
    {"float", "float"}, {"long", "long"}, {"reg", "register"}, {"short", "short"},
    {"signed", "signed"}, {"size", "sizeof"}, {"static", "static"}, {"select", "switch"},
    {"typedef", "typedef"}, {"union", "union"}, {"unsigned", "unsigned"}, {"volatile", "volatile"},
    {"infloop", "while"}, {"start_server", "start_server"}, {"add_route", "add_route"},
    {"add_middleware", "add_middleware"}, {"run_server", "run_server"},
    {"import", "#include"}, {"print", "printf"}, {"main", "main"},
    {NULL, NULL}
};

// Detecta limite de palavra
int is_word_boundary(char c) {
    if (c == '\0' || isspace(c)) return 1;
    if (isalnum(c) || c == '_') return 0;
    return 1;
}

// Substituição segura de palavras-chave
void replace_word(char* line, const char* old, const char* new_word) {
    char buffer[4096];
    int len_old = strlen(old);
    buffer[0] = '\0';
    char* p = line;
    int in_string = 0, in_char = 0, in_comment = 0;

    while (*p) {
        if (!in_string && !in_char && !in_comment && strncmp(p, "//", 2) == 0) {
            strcat(buffer, p);
            break;
        }
        if (!in_string && !in_char && !in_comment && strncmp(p, "/*", 2) == 0) {
            in_comment = 1;
            strncat(buffer, p, 2);
            p += 2;
            continue;
        }
        if (in_comment) {
            if (strncmp(p, "*/", 2) == 0) {
                in_comment = 0;
                strncat(buffer, p, 2);
                p += 2;
            } else {
                strncat(buffer, p, 1);
                p++;
            }
            continue;
        }
        if (!in_char && *p == '"') { in_string = !in_string; strncat(buffer, p, 1); p++; continue; }
        if (!in_string && *p == '\'') { in_char = !in_char; strncat(buffer, p, 1); p++; continue; }

        if (!in_string && !in_char && !in_comment &&
            (p == line || is_word_boundary(*(p-1))) &&
            strncmp(p, old, len_old) == 0 &&
            is_word_boundary(*(p+len_old))) {
            strcat(buffer, new_word);
            p += len_old;
        } else {
            strncat(buffer, p, 1);
            p++;
        }
    }
    strcpy(line, buffer);
}

// Remove ; do final da linha se necessário
void remove_semicolon(char* line) {
    int len = strlen(line);
    if (len > 0 && line[len-1] == ';') line[len-1] = '\0';
}

// Adiciona ; quando necessário
void ensure_semicolon(char* line) {
    int len = strlen(line);
    if (len == 0) return;
    char last = line[len-1];
    if (last != ';' && last != '{' && last != '}' &&
        strncmp(line, "#include", 8) != 0 &&
        strncmp(line, "#define", 7) != 0 &&
        strncmp(line, "int main", 8) != 0)
        strcat(line, ";");
}

// Processa declarações de função
void process_function_declaration(char* line) {
    if (strstr(line, "func ") == line) {
        char* paren = strchr(line, '(');
        if (!paren) return;
        char* params = paren + 1;
        char* end_paren = strchr(params, ')');
        if (!end_paren) return;

        char temp[1024];
        char* cursor = params;
        char* dest = temp;

        while (cursor < end_paren) {
            if (*cursor == ',') { *dest++ = *cursor++; continue; }
            else if (isalpha(*cursor) || *cursor == '_') {
                char param[64]; int i=0;
                while ((isalnum(*cursor) || *cursor == '_') && i<63) param[i++] = *cursor++;
                param[i] = '\0';
                if (strcmp(param,"req")==0) { strcpy(dest,"CRequest* req"); dest+=strlen("CRequest* req"); }
                else if (strcmp(param,"res")==0) { strcpy(dest,"CResponse* res"); dest+=strlen("CResponse* res"); }
                else if (strcmp(param,"server")==0) { strcpy(dest,"CServer* server"); dest+=strlen("CServer* server"); }
                else { strcpy(dest,"int "); dest+=4; strcpy(dest,param); dest+=strlen(param); }
            } else *dest++ = *cursor++;
        }
        *dest = '\0';
        memmove(paren+1,temp,strlen(temp)+1);
    }
}

// Processa imports
void process_imports(char* line) {
    if (strncmp(line,"import ",7)==0) {
        replace_word(line,"import","#include");
        if (!strchr(line,'"') && !strchr(line,'<')) {
            char temp[1024]; char* file=line+8;
            while (*file==' ') file++;
            snprintf(temp,sizeof(temp),"#include \"%s\"",file);
            strcpy(line,temp);
        }
    }
}

// Processa comentários @
void process_custom_comment(char* line) {
    if (line[0]=='@') {
        char buffer[1024];
        snprintf(buffer,sizeof(buffer),"//%s",line+1);
        strcpy(line,buffer);
    }
}

// Processa define
void process_define(char* line) {
    if (strncmp(line,"define ",7)==0) {
        char buffer[1024];
        snprintf(buffer,sizeof(buffer),"#%s",line);
        strcpy(line,buffer);
    }
}

int main(int argc,char* argv[]) {
    if(argc<2){ printf("Usage: %s file.cdog\n",argv[0]); return 1; }
    char* input_file=argv[1];
    char output_file[256];
    snprintf(output_file,sizeof(output_file),"%s.c",input_file);

    FILE* fin=fopen(input_file,"r");
    if(!fin){ printf("Error: Cannot open %s\n",input_file); return 1; }
    FILE* fout=fopen(output_file,"w");
    if(!fout){ fclose(fin); printf("Error: Cannot create %s\n",output_file); return 1; }

    fprintf(fout,
        "#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <ctype.h>\n#include \"caramel.h\"\n\n"
    );

    char line[1024];
    int inside_construct=0, inside_main=0;
    char construct_name[64];

    while(fgets(line,sizeof(line),fin)){
        line[strcspn(line,"\n")]=0;

        process_custom_comment(line);
        process_define(line);
        remove_semicolon(line);
        process_imports(line);

        if(!inside_construct && strstr(line,"construct")!=NULL){
            if(sscanf(line,"construct %63s",construct_name)==1){
                fprintf(fout,"struct %s {\n",construct_name);
                inside_construct=1; continue;
            }
        }

        if(inside_construct && strchr(line,'}')!=NULL){
            fprintf(fout,"};\n");
            inside_construct=0; continue;
        }

        process_function_declaration(line);

        if(strncmp(line,"main",4)==0 && strchr(line,'{')){
            strcpy(line,"int main(void) {");
            inside_main=1;
        }

        for(int i=0; keywords[i].custom!=NULL;i++)
            replace_word(line,keywords[i].custom,keywords[i].normal);

        ensure_semicolon(line);
        fprintf(fout,"%s\n",line);
    }

    if(inside_main) fprintf(fout,"return 0;\n}\n");

    fclose(fin);
    fclose(fout);

    printf("✅ Transpiled file: %s\n",output_file);

    char exe_file[256];
    strncpy(exe_file,input_file,sizeof(exe_file));
    char* dot=strrchr(exe_file,'.');
    if(dot && strcmp(dot,".cdog")==0) *dot='\0';

    char cmd[512];
    snprintf(cmd,sizeof(cmd),"gcc -fdiagnostics-color=always %s -o %s -pthread",output_file,exe_file);
    int result=system(cmd);

    if(result==0) remove(output_file);
    else printf("❌ Compilation error (file kept for inspection)\n");

    return 0;
}