#ifndef LIBCDOG_VMEM_H
#define LIBCDOG_VMEM_H

#include "vmetal.h"

// ===================================================
// LibCdog — vmem.h
// Manipulação de memória para o ambiente bare-metal
// ===================================================

// Copia 'len' bytes de src para dest
static inline void *vmem_copy(void *dest, const void *src, u32 len) {
    u8 *d = (u8*)dest;
    const u8 *s = (const u8*)src;
    for (u32 i = 0; i < len; i++)
        d[i] = s[i];
    return dest;
}

// Define 'len' bytes de 'ptr' com o valor 'val'
static inline void *vmem_set(void *ptr, u8 val, u32 len) {
    u8 *p = (u8*)ptr;
    for (u32 i = 0; i < len; i++)
        p[i] = val;
    return ptr;
}

// Compara duas regiões de memória
static inline int vmem_cmp(const void *a, const void *b, u32 len) {
    const u8 *pa = (const u8*)a;
    const u8 *pb = (const u8*)b;
    for (u32 i = 0; i < len; i++) {
        if (pa[i] != pb[i])
            return pa[i] - pb[i];
    }
    return 0;
}

// Copia palavras de 32 bits (mais rápido em kernels)
static inline void *vmem_copy32(void *dest, const void *src, u32 words) {
    u32 *d = (u32*)dest;
    const u32 *s = (const u32*)src;
    for (u32 i = 0; i < words; i++)
        d[i] = s[i];
    return dest;
}

// ---------------------------------------------------
// Gerenciador de heap estático simples
// ---------------------------------------------------
// Define o início e fim da heap (por exemplo, após o kernel)
#define VMEM_HEAP_START 0x0100000   // 1 MB
#define VMEM_HEAP_END   0x0200000   // 2 MB

static u8 *vmem_heap_ptr = (u8*)VMEM_HEAP_START;

// Aloca uma região contínua de memória (sem free)
static inline void *vmem_alloc(u32 size) {
    if (vmem_heap_ptr + size >= (u8*)VMEM_HEAP_END)
        vmetal_panic("VMEM: heap overflow!");
    void *block = vmem_heap_ptr;
    vmem_heap_ptr += size;
    return block;
}

// Aloca memória zerada
static inline void *vmem_calloc(u32 count, u32 size) {
    void *ptr = vmem_alloc(count * size);
    vmem_set(ptr, 0, count * size);
    return ptr;
}

// Retorna o endereço atual da heap (útil pra debug)
static inline u32 vmem_heap_pos() {
    return (u32)vmem_heap_ptr;
}

// ---------------------------------------------------
// Utilidades extras
// ---------------------------------------------------

// Inverte bytes (endian swap)
static inline u32 vmem_swap32(u32 val) {
    return ((val >> 24) & 0x000000FF) |
           ((val >> 8)  & 0x0000FF00) |
           ((val << 8)  & 0x00FF0000) |
           ((val << 24) & 0xFF000000);
}

// Move uma região (sem sobrescrever)
static inline void *vmem_move(void *dest, const void *src, u32 len) {
    const u8 *s = (const u8*)src;
    u8 *d = (u8*)dest;
    if (d < s) {
        for (u32 i = 0; i < len; i++)
            d[i] = s[i];
    } else {
        for (u32 i = len; i > 0; i--)
            d[i-1] = s[i-1];
    }
    return dest;
}

#endif // LIBCDOG_VMEM_H