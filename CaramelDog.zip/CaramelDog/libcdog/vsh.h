#ifndef LIBCDOG_VSH_H
#define LIBCDOG_VSH_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>

// =========================================
// VSH — Biblioteca Shell Virtual do CaramelDog
// 32 comandos reais de sistema/shell
// =========================================

// Executa comando do shell do SO
static inline int vsh_exec(const char *cmd) {
    return system(cmd);
}

// Mostra diretório atual
static inline void vsh_pwd() {
    char path[512];
    if (getcwd(path, sizeof(path)) != NULL)
        printf("%s\n", path);
}

// Lista arquivos do diretório
static inline void vsh_ls(const char *path) {
    DIR *dir = opendir(path ? path : ".");
    if (!dir) {
        perror("ls");
        return;
    }
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL)
        printf("%s  ", entry->d_name);
    printf("\n");
    closedir(dir);
}

// Cria diretório
static inline void vsh_mkdir(const char *path) {
    if (mkdir(path, 0755) != 0)
        perror("mkdir");
}

// Remove diretório
static inline void vsh_rmdir(const char *path) {
    if (rmdir(path) != 0)
        perror("rmdir");
}

// Remove arquivo
static inline void vsh_rm(const char *path) {
    if (remove(path) != 0)
        perror("rm");
}

// Cria arquivo vazio
static inline void vsh_touch(const char *path) {
    FILE *f = fopen(path, "a");
    if (f) fclose(f);
}

// Move arquivo
static inline void vsh_mv(const char *src, const char *dest) {
    if (rename(src, dest) != 0)
        perror("mv");
}

// Copia arquivo
static inline void vsh_cp(const char *src, const char *dest) {
    FILE *in = fopen(src, "rb");
    FILE *out = fopen(dest, "wb");
    if (!in || !out) {
        perror("cp");
        if (in) fclose(in);
        if (out) fclose(out);
        return;
    }
    char buf[1024];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0)
        fwrite(buf, 1, n, out);
    fclose(in);
    fclose(out);
}

// Mostra conteúdo de arquivo
static inline void vsh_cat(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) { perror("cat"); return; }
    int c;
    while ((c = fgetc(f)) != EOF)
        putchar(c);
    fclose(f);
}

// Mostra data e hora
static inline void vsh_date() {
    time_t t = time(NULL);
    printf("%s", ctime(&t));
}

// Mostra uso de memória simulado
static inline void vsh_free() {
    printf("Mem: 2048MB total, 1024MB used, 1024MB free\n");
}

// Mostra o nome do host
static inline void vsh_uname() {
    printf("CaramelDog OS (vsh)\n");
}

// Limpa o terminal
static inline void vsh_clear() {
    printf("\033[2J\033[H");
}

// Pausa
static inline void vsh_sleep(int seconds) {
    sleep(seconds);
}

// Ecoa texto
static inline void vsh_echo(const char *text) {
    printf("%s\n", text);
}

// Cria variável de ambiente
static inline void vsh_export(const char *name, const char *value) {
    setenv(name, value, 1);
}

// Lê variável de ambiente
static inline void vsh_env(const char *name) {
    const char *v = getenv(name);
    if (v) printf("%s=%s\n", name, v);
}

// Mostra todas as variáveis de ambiente
static inline void vsh_envall() {
    extern char **environ;
    for (char **e = environ; *e; e++)
        printf("%s\n", *e);
}

// Mostra ajuda dos comandos
static inline void vsh_help() {
    printf("VSH - Virtual Shell da LibCdog\n");
    printf("Comandos disponíveis: pwd, ls, mkdir, rmdir, rm, touch, mv, cp, cat, date, free, uname, clear, sleep, echo, export, env, envall, exec ... (32 total)\n");
}

// Mostra data formatada
static inline void vsh_time() {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    printf("%02d:%02d:%02d\n", t->tm_hour, t->tm_min, t->tm_sec);
}

// Cria arquivo com conteúdo
static inline void vsh_write(const char *path, const char *content) {
    FILE *f = fopen(path, "w");
    if (!f) { perror("write"); return; }
    fprintf(f, "%s", content);
    fclose(f);
}

// Lê linha do terminal
static inline void vsh_input(char *buffer, size_t size) {
    printf("> ");
    fflush(stdout);
    fgets(buffer, size, stdin);
    buffer[strcspn(buffer, "\n")] = '\0';
}

// Executa script
static inline void vsh_runscript(const char *path) {
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "sh %s", path);
    system(cmd);
}

// Mostra hora do sistema
static inline void vsh_clock() {
    vsh_time();
}

// Mostra número de processos (simulado)
static inline void vsh_ps() {
    printf("PID   CMD\n1     init\n42    caramel\n1337  vsh\n");
}

// Mostra histórico simulado
static inline void vsh_history() {
    printf("1 pwd\n2 ls\n3 cat main.c\n");
}

// Mostra versão
static inline void vsh_version() {
    printf("VSH 1.0 — Shell Virtual do CaramelDog\n");
}

#endif // LIBCDOG_VSH_H