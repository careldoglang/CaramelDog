#ifndef LIBCDOG_VMETAL_H
#define LIBCDOG_VMETAL_H

// ===================================================
// LibCdog — vmetal.h
// Núcleo bare-metal do CaramelDog
// Permite criar sistemas operacionais e kernels simples
// ===================================================

// Tipos primitivos fixos
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef unsigned long  u64;
typedef signed char    i8;
typedef signed short   i16;
typedef signed int     i32;
typedef signed long    i64;

// ---------------------------------------------------
// Controle de CPU
// ---------------------------------------------------
#define HALT() asm volatile("hlt")
#define CLI()  asm volatile("cli")
#define STI()  asm volatile("sti")
#define NOP()  asm volatile("nop")

// ---------------------------------------------------
// VGA Text Mode (0xB8000)
// ---------------------------------------------------
#define VGA_ADDRESS 0xB8000
#define VGA_COLS 80
#define VGA_ROWS 25

static volatile u16 *vga_buffer = (u16*)VGA_ADDRESS;
static u8 vga_color = 0x07; // branco em preto
static u8 cursor_row = 0, cursor_col = 0;

// Combina caractere + cor em um word de 16 bits
static inline u16 vmetal_vga_entry(char c, u8 color) {
    return (u16)c | (u16)color << 8;
}

// Limpa a tela
static inline void vmetal_clear() {
    for (u32 y = 0; y < VGA_ROWS; y++) {
        for (u32 x = 0; x < VGA_COLS; x++) {
            vga_buffer[y * VGA_COLS + x] = vmetal_vga_entry(' ', vga_color);
        }
    }
    cursor_row = 0;
    cursor_col = 0;
}

// Mostra um caractere
static inline void vmetal_putc(char c) {
    if (c == '\n') {
        cursor_row++;
        cursor_col = 0;
    } else {
        vga_buffer[cursor_row * VGA_COLS + cursor_col] = vmetal_vga_entry(c, vga_color);
        cursor_col++;
        if (cursor_col >= VGA_COLS) {
            cursor_col = 0;
            cursor_row++;
        }
    }
    if (cursor_row >= VGA_ROWS) {
        cursor_row = 0;
    }
}

// Mostra uma string
static inline void vmetal_print(const char *s) {
    for (u32 i = 0; s[i] != 0; i++)
        vmetal_putc(s[i]);
}

// Mostra uma string com quebra de linha
static inline void vmetal_println(const char *s) {
    vmetal_print(s);
    vmetal_putc('\n');
}

// ---------------------------------------------------
// Entrada simples (teclado PS/2)
// ---------------------------------------------------
static inline char vmetal_getkey() {
    unsigned char scancode;
    asm volatile("inb $0x60, %0" : "=a"(scancode));

    // mapa simples de teclado US
    static const char map[128] = {
        0, 27, '1','2','3','4','5','6','7','8','9','0','-','=','\b',
        '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',0,
        'a','s','d','f','g','h','j','k','l',';','\'','`',0,'\\','z',
        'x','c','v','b','n','m',',','.','/',0,'*',0,' ',0
    };
    if (scancode < 128)
        return map[scancode];
    return 0;
}

// Lê uma string básica (até Enter)
static inline void vmetal_input(char *buf, int max) {
    int i = 0;
    while (i < max - 1) {
        char c = vmetal_getkey();
        if (c) {
            if (c == '\n' || c == '\r') {
                vmetal_putc('\n');
                break;
            }
            buf[i++] = c;
            vmetal_putc(c);
        }
    }
    buf[i] = 0;
}

// ---------------------------------------------------
// Funções de debug e erro
// ---------------------------------------------------
static inline void vmetal_panic(const char *msg) {
    vmetal_clear();
    vga_color = 0x4F; // branco em vermelho
    vmetal_print("PANIC: ");
    vmetal_println(msg);
    HALT();
}

#endif // LIBCDOG_VMETAL_H