#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
    #include <windows.h>
    #define OS_WINDOWS 1
#else
    #include <unistd.h>
    #include <sys/wait.h>
    #define OS_WINDOWS 0
#endif

// Nossa própria implementação do system
int sh(const char *command) {
    if (command == NULL) {
        printf("my_system: Comando nulo. Verificando se shell está disponível.\n");
        
        #ifdef _WIN32
            return system(NULL); // Verifica se cmd.exe existe
        #else
            return system(NULL); // Verifica se /bin/sh existe
        #endif
    }
    
    
    
    #ifdef _WIN32
        // Implementação para Windows
        STARTUPINFO si;
        PROCESS_INFORMATION pi;
        
        ZeroMemory(&si, sizeof(si));
        si.cb = sizeof(si);
        ZeroMemory(&pi, sizeof(pi));
        
        // Cria uma cópia modificável do comando
        char cmd[1024];
        snprintf(cmd, sizeof(cmd), "cmd.exe /c %s", command);
        
        // Cria o processo
        if (!CreateProcess(
            NULL,   // No module name (use command line)
            cmd,    // Command line
            NULL,   // Process handle not inheritable
            NULL,   // Thread handle not inheritable
            FALSE,  // Set handle inheritance to FALSE
            0,      // No creation flags
            NULL,   // Use parent's environment block
            NULL,   // Use parent's starting directory
            &si,    // Pointer to STARTUPINFO structure
            &pi)    // Pointer to PROCESS_INFORMATION structure
        ) {
            printf("Erro ao criar processo (code: %lu)\n", GetLastError());
            return -1;
        }
        
        // Espera o processo terminar
        WaitForSingleObject(pi.hProcess, INFINITE);
        
        // Obtém o código de saída
        DWORD exit_code;
        GetExitCodeProcess(pi.hProcess, &exit_code);
        
        // Fecha os handles
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        
        return (int)exit_code;
        
    #else
        // Implementação para Linux/Unix
        pid_t pid = fork();
        
        if (pid == -1) {
            // Erro no fork
            perror("fork");
            return -1;
        }
        else if (pid == 0) {
            // Processo filho
            execl("/bin/sh", "sh", "-c", command, NULL);
            
            // Se chegou aqui, execl falhou
            perror("execl");
            exit(127);
        }
        else {
            // Processo pai
            int status;
            waitpid(pid, &status, 0);
            
            if (WIFEXITED(status)) {
                return WEXITSTATUS(status);
            } else {
                return -1;
            }
        }
    #endif
}

