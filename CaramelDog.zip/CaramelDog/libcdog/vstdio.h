// vstdio.h — biblioteca padrão do CaramelDog
// Versão inicial: matemática, texto e tabela Loid
// Autor: comunidade brazuca

#ifndef VSTDIO_H
#define VSTDIO_H

#include <stdio.h>
#include <math.h>
#include <string.h>

// Constantes matemáticas
#define PI   3.14159265358979323846
#define TAU  6.28318530717958647692
#define E    2.71828182845904523536
#define PHI  1.61803398874989484820
#define SQRT2 1.41421356237309504880
#define LN2   0.69314718055994530942
#define DEG2RAD (PI / 180.0)
#define RAD2DEG (180.0 / PI)

// Constantes lógicas e genéricas
#define TRUE  1
#define FALSE 0
#define YES   1
#define NO    0
#define OK    0
#define ERR  -1

// Macros de IO
#define print_line(text) printf("%s\n", text)
#define print_value(fmt, val) printf(fmt "\n", val)

// Estrutura da Tabela Loid
typedef struct {
    const char *symbols[128];
} LoidTable;

// Inicializa a Tabela Loid (ASCII)
static inline LoidTable init_loid_table() {
    static const LoidTable table = {
        .symbols = {
            "NUL","SOH","STX","ETX","EOT","ENQ","ACK","BEL",
            "BS","TAB","LF","VT","FF","CR","SO","SI",
            "DLE","DC1","DC2","DC3","DC4","NAK","SYN","ETB",
            "CAN","EM","SUB","ESC","FS","GS","RS","US",
            " ","!","\"","#","$","%","&","'","(",")","*","+",
            ",","-",".","/","0","1","2","3","4","5","6","7",
            "8","9",":",";","<","=",">","?","@",
            "A","B","C","D","E","F","G","H","I","J","K","L",
            "M","N","O","P","Q","R","S","T","U","V","W","X",
            "Y","Z","[","\\","]","^","_","`",
            "a","b","c","d","e","f","g","h","i","j","k","l",
            "m","n","o","p","q","r","s","t","u","v","w","x",
            "y","z","{","|","}","~","DEL"
        }
    };
    return table;
}

// Retorna o símbolo Loid de um código ASCII
static inline const char *loid_symbol(int code) {
    static LoidTable table;
    static int initialized = 0;
    if (!initialized) {
        table = init_loid_table();
        initialized = 1;
    }

    if (code < 0 || code >= 128)
        return "???";

    return table.symbols[code];
}

// Função bark — mascote padrão
static inline void bark(const char *msg) {
    printf("🐶 %s\n", msg);
}

// Funções matemáticas básicas
static inline double sq(double x) {
    return x * x;
}

static inline double deg(double x) {
    return x * RAD2DEG;
}

static inline double rad(double x) {
    return x * DEG2RAD;
}

#endif // VSTDIO_H