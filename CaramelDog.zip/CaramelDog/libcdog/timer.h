// timecdog.h
// Biblioteca simples de tempo — versão inicial
// Autor: Cal (CaramelDog Project)

#ifndef TIMECDOG_H
#define TIMECDOG_H

#ifdef _WIN32
    #include <windows.h>
    #include <time.h>
#else
    #include <unistd.h>
    #include <sys/time.h>
    #include <time.h>
#endif

// Retorna hora atual em string formatada "HH:MM:SS"
static inline const char* timecdog_now() {
    static char buffer[16];
    time_t t = time(NULL);
    struct tm *tm_info = localtime(&t);
    strftime(buffer, sizeof(buffer), "%H:%M:%S", tm_info);
    return buffer;
}

// Pausa a execução (sleep) em segundos
static inline void timecdog_sleep(int seconds) {
#ifdef _WIN32
    Sleep(seconds * 1000);
#else
    sleep(seconds);
#endif
}

// Retorna o tempo atual em milissegundos desde a epoch
static inline long long timecdog_ms() {
#ifdef _WIN32
    FILETIME ft;
    GetSystemTimeAsFileTime(&ft);
    unsigned long long t = ((unsigned long long)ft.dwHighDateTime << 32) | ft.dwLowDateTime;
    return (t / 10000ULL);
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (tv.tv_sec * 1000LL) + (tv.tv_usec / 1000LL);
#endif
}

// Medição de tempo (timer simples)
typedef struct {
    long long start;
} timecdog_timer;

static inline timecdog_timer timecdog_start() {
    timecdog_timer t;
    t.start = timecdog_ms();
    return t;
}

static inline long long timecdog_elapsed(timecdog_timer t) {
    return timecdog_ms() - t.start;
}

#endif // TIMECDOG_H