#ifndef CARAMEL_H
#define CARAMEL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ----------------- Função include para arquivos .p -----------------
static char* include(const char* filename) {
    FILE* f = fopen(filename, "r");
    if (!f) {
        fprintf(stderr, "Erro: não foi possível abrir %s\n", filename);
        return NULL;
    }

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);

    char* buffer = (char*)malloc(size + 1);
    if (!buffer) {
        fclose(f);
        fprintf(stderr, "Erro: memória insuficiente para incluir %s\n", filename);
        return NULL;
    }

    fread(buffer, 1, size, f);
    buffer[size] = '\0';
    fclose(f);

    return buffer;
}

// ----------------- Macros para classes -----------------
#define class(name) \
    typedef struct name name; \
    struct name

#define method(cls, ret_type, name, ...) \
    ret_type (*name)(cls* self, ##__VA_ARGS__)

#define init_method(cls) cls* init_##cls()
#define new(cls) init_##cls()
#define delete(obj) free(obj)

// ----------------- Herança -----------------
#define inherit(child, parent) \
    parent parent_part;

// ----------------- Métodos virtuais -----------------
#define virtual(method) method
#define override(method) method

// ----------------- Gerenciador de variáveis -----------------
typedef struct {
    const char* name;
    int access_count;
    void* ptr;
} varinfo;

#define MAX_VARS 64

typedef struct {
    varinfo vars[MAX_VARS];
    int count;
} var_manager;

static void var_manager_init(var_manager* vm) {
    vm->count = 0;
}

static void var_manager_register(var_manager* vm, const char* name, void* ptr) {
    if (vm->count >= MAX_VARS) return;
    vm->vars[vm->count].name = name;
    vm->vars[vm->count].ptr = ptr;
    vm->vars[vm->count].access_count = 0;
    vm->count++;
}

static void var_manager_access(var_manager* vm, const char* name) {
    for (int i = 0; i < vm->count; i++) {
        if (strcmp(vm->vars[i].name, name) == 0) {
            vm->vars[i].access_count++;
            break;
        }
    }
}

static void var_manager_report(var_manager* vm) {
    printf("---- Variáveis mais usadas ----\n");
    for (int i = 0; i < vm->count; i++) {
        printf("%s: %d acessos\n", vm->vars[i].name, vm->vars[i].access_count);
    }
}

static void var_manager_optimize(var_manager* vm) {
    printf("---- Otimizando variáveis ----\n");
    for (int i = 0; i < vm->count; i++) {
        if (vm->vars[i].access_count > 2) {
            printf("Variável %s recomendada para register\n", vm->vars[i].name);
        }
    }
}

#endif 
#ifndef CARAMEL_WEB_H
#define CARAMEL_WEB_H

/* caramel_web.h
 *
 * Minimal, robust-ish HTTP server library for "Cachorro Caramelo".
 * - Uses POSIX sockets and pthreads (sys/socket.h, netinet/in.h, arpa/inet.h)
 * - Multi-threaded: one thread per connection (basic)
 * - Routing, middleware, simple template support, JSON helper
 *
 * NOTE: This is intentionally self-contained (no libcurl, no external deps).
 *       For production-scale use add: thread-pool, epoll/IO_URING, caches, TLS, etc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>
#include <sys/stat.h>

#define CWEB_MAX_BUF        16384
#define CWEB_MAX_PATH       512
#define CWEB_MAX_ROUTES     128
#define CWEB_MAX_MIDDLEWARE 32
#define CWEB_MAX_HEADERS    64
#define CWEB_MAX_HEADER_LEN 1024

typedef struct {
    char key[128];
    char value[1024];
} Header;

typedef struct {
    char method[8];
    char path[CWEB_MAX_PATH];
    char raw_path[CWEB_MAX_PATH];
    char query[1024];
    Header headers[CWEB_MAX_HEADERS];
    int header_count;
    char body[CWEB_MAX_BUF];
    int body_len;
} CRequest;

typedef struct {
    int client_fd;
} CResponse;

/* handler signature */
typedef void (*croute_handler_t)(CRequest* req, CResponse* res);
typedef void (*cmiddleware_t)(CRequest* req, CResponse* res);

typedef struct {
    char path[CWEB_MAX_PATH]; /* exact match only in this version; can be extended */
    char method[8];           /* "GET", "POST" or "*" for any */
    croute_handler_t handler;
} CRoute;

typedef struct {
    int port;
    int server_fd;
    CRoute routes[CWEB_MAX_ROUTES];
    int route_count;
    cmiddleware_t middlewares[CWEB_MAX_MIDDLEWARE];
    int middleware_count;
    int backlog;
} CServer;

/* ----------- Utilities ----------- */

static void cweb_log(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    time_t t = time(NULL);
    struct tm tm;
    localtime_r(&t, &tm);
    char timestr[32];
    strftime(timestr, sizeof(timestr), "%Y-%m-%d %H:%M:%S", &tm);
    printf("[%s] ", timestr);
    vprintf(fmt, ap);
    printf("\n");
    va_end(ap);
}

static void trim_trailing_whitespace(char* s) {
    int i = strlen(s) - 1;
    while (i >= 0 && (s[i] == '\r' || s[i] == '\n' || s[i] == ' ' || s[i] == '\t')) {
        s[i] = '\0';
        i--;
    }
}

/* safe write all */
static ssize_t write_all(int fd, const void* buf, size_t count) {
    const char* p = buf;
    size_t left = count;
    while (left > 0) {
        ssize_t w = write(fd, p, left);
        if (w <= 0) return w;
        p += w; left -= w;
    }
    return count;
}

/* URL-decode minimal */
static void url_decode(char* dst, const char* src) {
    char a, b;
    while (*src) {
        if ((*src == '%') && ((a = src[1]) && (b = src[2])) && (isxdigit(a) && isxdigit(b))) {
            char hex[3] = {a, b, 0};
            *dst++ = (char) strtol(hex, NULL, 16);
            src += 3;
        } else if (*src == '+') {
            *dst++ = ' ';
            src++;
        } else {
            *dst++ = *src++;
        }
    }
    *dst = '\0';
}

/* get header (case-insensitive) */
static const char* crequest_get_header(CRequest* req, const char* key) {
    for (int i=0;i<req->header_count;i++) {
        if (strcasecmp(req->headers[i].key, key) == 0) return req->headers[i].value;
    }
    return NULL;
}

/* get query param by name (first match) */
static int crequest_get_query_param(CRequest* req, const char* name, char* out, int outlen) {
    if (!req->query || !req->query[0]) return 0;
    char qdup[1024]; strncpy(qdup, req->query, sizeof(qdup)-1);
    char* token = strtok(qdup, "&");
    while (token) {
        char* eq = strchr(token, '=');
        if (eq) {
            *eq = '\0';
            char* k = token;
            char* v = eq+1;
            if (strcmp(k, name) == 0) {
                url_decode(out, v);
                return 1;
            }
        } else {
            if (strcmp(token, name) == 0) { out[0]='\0'; return 1; }
        }
        token = strtok(NULL, "&");
    }
    return 0;
}

/* ----------- Response helpers ----------- */

static void cresponse_send_text(CResponse* res, const char* body) {
    char header[256];
    snprintf(header, sizeof(header),
             "HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
             strlen(body));
    write_all(res->client_fd, header, strlen(header));
    write_all(res->client_fd, body, strlen(body));
}

static void cresponse_send_status(CResponse* res, int status, const char* status_text, const char* body) {
    char header[256];
    snprintf(header, sizeof(header),
             "HTTP/1.1 %d %s\r\nContent-Type: text/plain\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
             status, status_text, strlen(body));
    write_all(res->client_fd, header, strlen(header));
    write_all(res->client_fd, body, strlen(body));
}

static void cresponse_send_json(CResponse* res, const char* json_body) {
    char header[256];
    snprintf(header, sizeof(header),
             "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
             strlen(json_body));
    write_all(res->client_fd, header, strlen(header));
    write_all(res->client_fd, json_body, strlen(json_body));
}

static void cresponse_send_file(CResponse* res, const char* filepath) {
    struct stat st;
    if (stat(filepath, &st) != 0) {
        cresponse_send_status(res, 404, "Not Found", "404 Not Found");
        return;
    }
    FILE* f = fopen(filepath, "rb");
    if (!f) { cresponse_send_status(res, 500, "IO Error", "500"); return; }
    size_t size = st.st_size;
    char header[256];
    snprintf(header, sizeof(header),
             "HTTP/1.1 200 OK\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n", size);
    write_all(res->client_fd, header, strlen(header));
    char buf[4096];
    size_t r;
    while ((r = fread(buf,1,sizeof(buf),f)) > 0) write_all(res->client_fd, buf, r);
    fclose(f);
}

/* simple JSON builder helpers (tiny): create object like {"k":"v"} by formatting */
static void json_escape_simple(const char* in, char* out, int outlen) {
    int j=0;
    for (int i=0; in[i] && j+1<outlen; i++) {
        char c = in[i];
        if (c == '"' || c=='\\') { if (j+2 < outlen) { out[j++]='\\'; out[j++]=c; } }
        else if (c == '\n') { if (j+2 < outlen) { out[j++]='\\'; out[j++]='n'; } }
        else out[j++]=c;
    }
    out[j]='\0';
}

/* ----------- Request parsing ----------- */

/* parse request line + headers (very tolerant) */
static void parse_http_request(char* raw, CRequest* req) {
    memset(req, 0, sizeof(CRequest));
    req->header_count = 0;
    req->body_len = 0;

    char* p = raw;
    /* request line */
    char method[16], pathfull[1024];
    if (sscanf(p, "%15s %1023s", method, pathfull) != 2) {
        strncpy(req->method, "GET", sizeof(req->method)-1);
        strcpy(req->path, "/");
        return;
    }
    strncpy(req->method, method, sizeof(req->method)-1);
    /* split path and query */
    char* qpos = strchr(pathfull, '?');
    if (qpos) {
        size_t pathlen = qpos - pathfull;
        if (pathlen >= sizeof(req->path)) pathlen = sizeof(req->path)-1;
        strncpy(req->path, pathfull, pathlen);
        req->path[pathlen]='\0';
        strncpy(req->query, qpos+1, sizeof(req->query)-1);
    } else {
        strncpy(req->path, pathfull, sizeof(req->path)-1);
        req->query[0]='\0';
    }
    strncpy(req->raw_path, req->path, sizeof(req->raw_path)-1);

    /* move p to line after request line */
    char* line = strchr(p, '\n');
    if (!line) return;
    p = line + 1;

    /* headers */
    while (*p && !(p[0] == '\r' && p[1] == '\n')) {
        char header_line[1024] = {0};
        char* nxt = strchr(p, '\n');
        if (!nxt) { strncpy(header_line, p, sizeof(header_line)-1); p += strlen(p); break;}
        size_t len = nxt - p;
        if (len >= sizeof(header_line)) len = sizeof(header_line)-1;
        strncpy(header_line, p, len);
        trim_trailing_whitespace(header_line);

        char* colon = strchr(header_line, ':');
        if (colon) {
            *colon = '\0';
            char* key = header_line;
            char* val = colon+1;
            while (*val == ' ') val++;
            if (req->header_count < CWEB_MAX_HEADERS) {
                strncpy(req->headers[req->header_count].key, key, sizeof(req->headers[req->header_count].key)-1);
                strncpy(req->headers[req->header_count].value, val, sizeof(req->headers[req->header_count].value)-1);
                req->header_count++;
            }
        }
        p = nxt + 1;
    }

    /* body (after \r\n\r\n) */
    char* body_start = strstr(raw, "\r\n\r\n");
    if (body_start) {
        body_start += 4;
        size_t blen = strlen(body_start);
        if (blen > sizeof(req->body)-1) blen = sizeof(req->body)-1;
        memcpy(req->body, body_start, blen);
        req->body[blen] = '\0';
        req->body_len = blen;
    }
}

/* ----------- Thread handling ----------- */

typedef struct {
    int client_fd;
    CServer* server;
} client_thread_arg_t;

static void* cweb_client_thread(void* arg) {
    client_thread_arg_t* ta = (client_thread_arg_t*)arg;
    int client_fd = ta->client_fd;
    CServer* server = ta->server;
    free(arg);

    char raw[CWEB_MAX_BUF];
    ssize_t r = read(client_fd, raw, sizeof(raw)-1);
    if (r <= 0) { close(client_fd); return NULL; }
    raw[r] = '\0';

    CRequest req;
    CResponse res;
    res.client_fd = client_fd;
    parse_http_request(raw, &req);

    cweb_log("%s %s", req.method, req.path);

    /* run middleware chain */
    for (int i=0;i<server->middleware_count;i++) {
        server->middlewares[i](&req, &res);
    }

    /* route dispatch (exact match) */
    int matched = 0;
    for (int i=0;i<server->route_count;i++) {
        if ((strcmp(server->routes[i].path, req.path) == 0 || strcmp(server->routes[i].path, "*") == 0) &&
            (strcmp(server->routes[i].method, "*") == 0 || strcmp(server->routes[i].method, req.method) == 0)) {
            server->routes[i].handler(&req, &res);
            matched = 1;
            break;
        }
    }
    if (!matched) {
        cresponse_send_status(&res, 404, "Not Found", "404 Not Found");
    }

    close(client_fd);
    return NULL;
}

/* ----------- Server API ----------- */

static CServer* start_server(int port) {
    CServer* s = (CServer*)malloc(sizeof(CServer));
    if (!s) return NULL;
    s->port = port;
    s->route_count = 0;
    s->middleware_count = 0;
    s->backlog = 128;

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) { perror("socket"); free(s); return NULL; }

    int opt = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind"); close(sock); free(s); return NULL;
    }
    if (listen(sock, s->backlog) < 0) { perror("listen"); close(sock); free(s); return NULL; }

    s->server_fd = sock;
    cweb_log("Cachorro Caramelo server started on port %d", port);
    return s;
}

static void add_route(CServer* s, const char* method, const char* path, croute_handler_t handler) {
    if (!s || s->route_count >= CWEB_MAX_ROUTES) return;
    strncpy(s->routes[s->route_count].method, method, sizeof(s->routes[s->route_count].method)-1);
    strncpy(s->routes[s->route_count].path, path, sizeof(s->routes[s->route_count].path)-1);
    s->routes[s->route_count].handler = handler;
    s->route_count++;
}

static void add_middleware(CServer* s, cmiddleware_t m) {
    if (!s || s->middleware_count >= CWEB_MAX_MIDDLEWARE) return;
    s->middlewares[s->middleware_count++] = m;
}

static void run_server(CServer* s) {
    if (!s) return;
    while (1) {
        struct sockaddr_in client_addr;
        socklen_t alen = sizeof(client_addr);
        int client_fd = accept(s->server_fd, (struct sockaddr*)&client_addr, &alen);
        if (client_fd < 0) { perror("accept"); continue; }
        client_thread_arg_t* ta = malloc(sizeof(client_thread_arg_t));
        ta->client_fd = client_fd;
        ta->server = s;
        pthread_t tid;
        pthread_create(&tid, NULL, cweb_client_thread, ta);
        pthread_detach(tid);
    }
}

/* ----------- Tiny Template helper -----------
   Replace occurrences of {key} in template with value.
   Usage: char out[...] ; cweb_render_template(template, "{name}", "Alice", out, sizeof(out));
*/
static void cweb_render_template(const char* tmpl, const char* placeholder, const char* value, char* out, int outlen) {
    out[0]='\0';
    const char* p = tmpl;
    while (*p && (int)strlen(out) + 1 < outlen) {
        const char* pos = strstr(p, placeholder);
        if (!pos) {
            strncat(out, p, outlen - strlen(out) - 1);
            break;
        }
        int chunk = pos - p;
        if (chunk > 0) strncat(out, p, (outlen - strlen(out) - 1) < chunk ? (outlen-strlen(out)-1) : chunk);
        strncat(out, value, outlen - strlen(out) - 1);
        p = pos + strlen(placeholder);
    }
}

/* ----------- Convenience macro-like wrappers for "Cachorro Caramelo" preprocessor
   Expose names that map easily:
   - start_server -> start_server
   - add_route(server, "GET", "/x", handler) -> add_route(...)
   - add_middleware(server, mw) -> add_middleware(...)
   - run_server(server) -> run_server(server)
*/

#endif /* CARAMEL_WEB_H */
#ifndef MATH_CARAMEL
#define MATH_CARAMEL
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

// Constants
const double pi = 3.141592653589793;
const double euler = 2.718281828459045;
const double nan_val = NAN;
const double inf_val = INFINITY;

// Power and logarithmic functions
double sqrt_val(double x) { return sqrt(x); }
double cbrt_val(double x) { return cbrt(x); }
double pow_val(double base, double exp) { return pow(base, exp); }
double exp_val(double x) { return exp(x); }
double exp2_val(double x) { return exp2(x); }
double log_val(double x) { return log(x); }
double log10_val(double x) { return log10(x); }
double log2_val(double x) { return log2(x); }

// Trigonometric functions
double sin_val(double x) { return sin(x); }
double cos_val(double x) { return cos(x); }
double tan_val(double x) { return tan(x); }
double asin_val(double x) { return asin(x); }
double acos_val(double x) { return acos(x); }
double atan_val(double x) { return atan(x); }
double atan2_val(double y, double x) { return atan2(y, x); }

// Hyperbolic functions
double sinh_val(double x) { return sinh(x); }
double cosh_val(double x) { return cosh(x); }
double tanh_val(double x) { return tanh(x); }
double asinh_val(double x) { return asinh(x); }
double acosh_val(double x) { return acosh(x); }
double atanh_val(double x) { return atanh(x); }

// Rounding and remainder
double ceil_val(double x) { return ceil(x); }
double floor_val(double x) { return floor(x); }
double round_val(double x) { return round(x); }
double trunc_val(double x) { return trunc(x); }
double fmod_val(double x, double y) { return fmod(x, y); }
double remainder_val(double x, double y) { return remainder(x, y); }

// Absolute value
int abs_val(int x) { return abs(x); }
double fabs_val(double x) { return fabs(x); }

// Min/Max
double max_val(double a, double b) { return (a > b) ? a : b; }
double min_val(double a, double b) { return (a < b) ? a : b; }

// Degree-Radian conversions
double deg2rad(double deg) { return deg * (pi / 180.0); }
double rad2deg(double rad) { return rad * (180.0 / pi); }

// Extras
double factorial(int n) {
    if(n < 0) return NAN;
    double f = 1;
    for(int i = 2; i <= n; i++) f *= i;
    return f;
}

double omega3cubed(double omega) {
    // Omega multiplied by 3^(3^3)
    return omega * pow(3, pow(3, 3));
}

// Example statistical functions
double mean(double arr[], int size) {
    if(size <= 0) return NAN;
    double sum = 0;
    for(int i = 0; i < size; i++) sum += arr[i];
    return sum / size;
}

double variance(double arr[], int size) {
    if(size <= 0) return NAN;
    double m = mean(arr, size);
    double sum = 0;
    for(int i = 0; i < size; i++) sum += (arr[i]-m)*(arr[i]-m);
    return sum / size;
}

double stddev(double arr[], int size) {
    return sqrt_val(variance(arr, size));
}
#endif
#ifndef CFLASK_HTML_H
#define CFLASK_HTML_H


/* --------- Mini Flask for Browsers --------- */
typedef struct {
    CServer* server;
} CFlaskApp;

static CFlaskApp* flask_create(int port) {
    CFlaskApp* app = (CFlaskApp*)malloc(sizeof(CFlaskApp));
    if (!app) return NULL;
    app->server = start_server(port);
    return app;
}

static void flask_route(CFlaskApp* app, const char* method, const char* path, croute_handler_t handler) {
    add_route(app->server, method, path, handler);
}

static void flask_middleware(CFlaskApp* app, cmiddleware_t middleware) {
    add_middleware(app->server, middleware);
}

static void flask_run(CFlaskApp* app) {
    run_server(app->server);
}

/* --------- Response helpers HTML/JSON --------- */
static void flask_html(CResponse* res, const char* html) {
    char header[256];
    snprintf(header, sizeof(header),
        "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
        strlen(html));
    write_all(res->client_fd, header, strlen(header));
    write_all(res->client_fd, html, strlen(html));
}

static void flask_json(CResponse* res, const char* json) {
    cresponse_send_json(res, json);
}

static void flask_file(CResponse* res, const char* filepath) {
    cresponse_send_file(res, filepath);
}

static void flask_status(CResponse* res, int status, const char* message, const char* body) {
    cresponse_send_status(res, status, message, body);
}

/* --------- Template shortcut --------- */
static void flask_render(const char* template, const char* placeholder, const char* value, char* out, int outlen) {
    cweb_render_template(template, placeholder, value, out, outlen);
}

#endif /* CFLASK_HTML_H */
#ifndef CJSON_H
#define CJSON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* --------- JSON Value Types --------- */
typedef enum {
    JSON_NULL,
    JSON_BOOL,
    JSON_NUMBER,
    JSON_STRING,
    JSON_ARRAY,
    JSON_OBJECT
} JSONType;

typedef struct JSONValue JSONValue;

typedef struct {
    char* key;
    JSONValue* value;
} JSONPair;

struct JSONValue {
    JSONType type;
    union {
        double number;
        int boolean;
        char* string;
        struct {
            JSONValue** items;
            int count;
        } array;
        struct {
            JSONPair** pairs;
            int count;
        } object;
    };
};

/* --------- Lexer Helpers --------- */
static void skip_whitespace(const char** p) {
    while (isspace(**p)) (*p)++;
}

static int match(const char** p, char c) {
    skip_whitespace(p);
    if (**p == c) { (*p)++; return 1; }
    return 0;
}

static char* parse_string(const char** p) {
    if (!match(p, '"')) return NULL;
    const char* start = *p;
    char buffer[1024];
    int i=0;
    while (**p && **p != '"') {
        if (**p == '\\') { (*p)++; if (**p) buffer[i++] = **p; (*p)++; continue; }
        buffer[i++] = **p;
        (*p)++;
    }
    buffer[i]='\0';
    if (!match(p, '"')) return NULL;
    return strdup(buffer);
}

static double parse_number(const char** p) {
    skip_whitespace(p);
    char buffer[64];
    int i=0;
    while (isdigit(**p) || **p=='-' || **p=='+' || **p=='.' || **p=='e' || **p=='E') {
        buffer[i++] = **p;
        (*p)++;
        if (i >= 63) break;
    }
    buffer[i]='\0';
    return strtod(buffer,NULL);
}

/* --------- Forward declaration --------- */
static JSONValue* parse_value(const char** p);

/* --------- Array --------- */
static JSONValue* parse_array(const char** p) {
    if (!match(p,'[')) return NULL;
    JSONValue* val = (JSONValue*)malloc(sizeof(JSONValue));
    val->type = JSON_ARRAY;
    val->array.items = NULL;
    val->array.count = 0;

    while (!match(p,']')) {
        JSONValue* item = parse_value(p);
        if (!item) { free(val); return NULL; }
        val->array.items = (JSONValue**)realloc(val->array.items,sizeof(JSONValue*)*(val->array.count+1));
        val->array.items[val->array.count++] = item;
        match(p,',');
    }
    return val;
}

/* --------- Object --------- */
static JSONValue* parse_object(const char** p) {
    if (!match(p,'{')) return NULL;
    JSONValue* val = (JSONValue*)malloc(sizeof(JSONValue));
    val->type = JSON_OBJECT;
    val->object.pairs = NULL;
    val->object.count = 0;

    while (!match(p,'}')) {
        char* key = parse_string(p);
        if (!key) { free(val); return NULL; }
        if (!match(p,':')) { free(key); free(val); return NULL; }
        JSONValue* value = parse_value(p);
        if (!value) { free(key); free(val); return NULL; }
        JSONPair* pair = (JSONPair*)malloc(sizeof(JSONPair));
        pair->key = key; pair->value = value;
        val->object.pairs = (JSONPair**)realloc(val->object.pairs,sizeof(JSONPair*)*(val->object.count+1));
        val->object.pairs[val->object.count++] = pair;
        match(p,',');
    }
    return val;
}

/* --------- Value --------- */
static JSONValue* parse_value(const char** p) {
    skip_whitespace(p);
    if (**p=='"') return (JSONValue*) (JSONValue*)({ JSONValue* v=(JSONValue*)malloc(sizeof(JSONValue)); v->type=JSON_STRING; v->string=parse_string(p); v; });
    else if (**p=='{') return parse_object(p);
    else if (**p=='[') return parse_array(p);
    else if (strncmp(*p,"true",4)==0) { (*p)+=4; JSONValue* v=(JSONValue*)malloc(sizeof(JSONValue)); v->type=JSON_BOOL; v->boolean=1; return v; }
    else if (strncmp(*p,"false",5)==0) { (*p)+=5; JSONValue* v=(JSONValue*)malloc(sizeof(JSONValue)); v->type=JSON_BOOL; v->boolean=0; return v; }
    else if (strncmp(*p,"null",4)==0) { (*p)+=4; JSONValue* v=(JSONValue*)malloc(sizeof(JSONValue)); v->type=JSON_NULL; return v; }
    else return (JSONValue*)({ JSONValue* v=(JSONValue*)malloc(sizeof(JSONValue)); v->type=JSON_NUMBER; v->number=parse_number(p); v; });
}

/* --------- Parse JSON String --------- */
static JSONValue* json_parse(const char* text) {
    const char* p = text;
    return parse_value(&p);
}

/* --------- Simple JSON Builder (stringify) --------- */
static void json_stringify(JSONValue* val, char* out, int outlen) {
    if (!val) { snprintf(out,outlen,"null"); return; }
    switch(val->type) {
        case JSON_NULL: snprintf(out,outlen,"null"); break;
        case JSON_BOOL: snprintf(out,outlen,"%s",val->boolean?"true":"false"); break;
        case JSON_NUMBER: snprintf(out,outlen,"%g",val->number); break;
        case JSON_STRING: snprintf(out,outlen,"\"%s\"",val->string); break;
        case JSON_ARRAY: {
            strcat(out,"[");
            for(int i=0;i<val->array.count;i++){
                char buf[1024]="";
                json_stringify(val->array.items[i],buf,sizeof(buf));
                strcat(out,buf);
                if(i<val->array.count-1) strcat(out,",");
            }
            strcat(out,"]");
            break;
        }
        case JSON_OBJECT: {
            strcat(out,"{");
            for(int i=0;i<val->object.count;i++){
                char buf[1024]="";
                json_stringify(val->object.pairs[i]->value,buf,sizeof(buf));
                char tmp[2048]; snprintf(tmp,sizeof(tmp),"\"%s\":%s",val->object.pairs[i]->key,buf);
                strcat(out,tmp);
                if(i<val->object.count-1) strcat(out,",");
            }
            strcat(out,"}");
            break;
        }
    }
}

#endif
#ifndef CDOG_H
#define CDOG_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// ---------------- Keywords do CDog ----------------
typedef struct {
    const char* custom;
    const char* normal;
} Keyword;

static Keyword cdog_keywords[] = {
    {"if", "if"}, {"else", "else"}, {"loop", "for"}, {"ret", "return"},
    {"jump", "goto"}, {"construct", "struct"}, {"num", "int"}, {"str", "char*"},
    {"none", "void"}, {"func", "void"}, {"var", "auto"}, {"pause", "break"},
    {"ifcase", "case"}, {"const", "const"}, {"run", "continue"}, {"default", "default"},
    {"do", "do"}, {"decimal", "double"}, {"enum", "enum"}, {"extern", "extern"},
    {"float", "float"}, {"long", "long"}, {"reg", "register"}, {"short", "short"},
    {"signed", "signed"}, {"size", "sizeof"}, {"static", "static"}, {"select", "switch"},
    {"typedef", "typedef"}, {"union", "union"}, {"unsigned", "unsigned"}, {"volatile", "volatile"},
    {"infloop", "while"}, {"start_server", "start_server"}, {"add_route", "add_route"},
    {"add_middleware", "add_middleware"}, {"run_server", "run_server"},
    {"import", "#include"}, {"print", "printf"}, {"main", "main"},
    {NULL, NULL}
};

// ---------------- Helper para substituir palavras ----------------
static int is_word_boundary(char c) {
    if (c == '\0' || isspace(c)) return 1;
    if (isalnum(c) || c == '_') return 0;
    return 1;
}

static void replace_keywords(char* line) {
    for (int i = 0; cdog_keywords[i].custom != NULL; i++) {
        const char* old = cdog_keywords[i].custom;
        const char* new_word = cdog_keywords[i].normal;
        int len_old = strlen(old);
        char buffer[4096];
        char* p = line;
        char* dest = buffer;
        int in_string=0, in_char=0;
        while (*p) {
            if (!in_char && *p=='"') { in_string=!in_string; *dest++=*p++; continue; }
            if (!in_string && *p=='\'') { in_char=!in_char; *dest++=*p++; continue; }
            if (!in_string && !in_char &&
                (p==line || is_word_boundary(*(p-1))) &&
                strncmp(p, old, len_old)==0 &&
                is_word_boundary(*(p+len_old))) {
                strcpy(dest, new_word);
                dest += strlen(new_word);
                p += len_old;
            } else *dest++=*p++;
        }
        *dest='\0';
        strcpy(line, buffer);
    }
}

// ---------------- Cria arquivo temporário e transpila ----------------
static int Cdog_compile_lines(const char* filename, const char** lines, int count) {
    char output_file[256];
    snprintf(output_file, sizeof(output_file), "%s.c", filename);

    FILE* fout = fopen(output_file, "w");
    if (!fout) return 0;

    fprintf(fout,
        "#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <ctype.h>\n#include \"caramel.h\"\n\n"
    );

    char buffer[1024];
    for (int i=0;i<count;i++){
        strncpy(buffer, lines[i], sizeof(buffer)-1);
        buffer[sizeof(buffer)-1]='\0';
        replace_keywords(buffer);
        fprintf(fout, "%s\n", buffer);
    }

    fclose(fout);

    char exe_file[256];
    strncpy(exe_file, filename, sizeof(exe_file));
    char* dot = strrchr(exe_file, '.');
    if (dot) *dot = '\0';

    char cmd[512];
    snprintf(cmd, sizeof(cmd), "gcc -fdiagnostics-color=always %s -o %s -pthread", output_file, exe_file);
    int result = system(cmd);

    if (result == 0) {
        remove(output_file);
        printf("✅ Compiled successfully: %s\n", exe_file);
        return 1;
    } else {
        printf("❌ Compilation error (check %s)\n", output_file);
        return 0;
    }
}

// ---------------- Macro variádico ----------------
#define Cdog_compile(...) do { \
    const char* lines[] = {__VA_ARGS__}; \
    Cdog_compile_lines("cdog_temp", lines, sizeof(lines)/sizeof(lines[0])); \
} while(0)

#endif