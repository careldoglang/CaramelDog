import os
os.system("./caramelcc test.cdog")