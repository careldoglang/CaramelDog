import marshal
import tarfile
import os

# Passo 1: Cria o bytecode do Python (.pkk)
py_file = "example.py"  # arquivo Python de entrada
pkk_file = "exemplo.pkk"  # arquivo que vai dentro do tar

with open(py_file, "r") as f:
    code = f.read()

code_object = compile(code, py_file, "exec")
byte_code = marshal.dumps(code_object)

with open(pkk_file, "wb") as f:
    f.write(byte_code)

# Passo 2: Compacta em tar.xz
tar_file = "exemplo.tar.xz"
with tarfile.open(tar_file, "w:xz") as tar:
    tar.add(pkk_file)

# Passo 3: Cria o arquivo .hkk com header + indicador + tar.xz
hkk_file = "exemplo.hkk"
header = bytes([0x09, 0x90, 0x46, 0x57, 0x22, 0x56, 0x77, 0x19])
indicator = bytes([0x11, 0x54, 0x68, 0x68])  # tar.xz

with open(tar_file, "rb") as f:
    body = f.read()

with open(hkk_file, "wb") as f:
    f.write(header)
    f.write(indicator)
    f.write(body)

# Limpeza opcional
os.remove(pkk_file)
os.remove(tar_file)

print(f"{hkk_file} criado com sucesso!")