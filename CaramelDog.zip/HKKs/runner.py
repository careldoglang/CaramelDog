import tarfile
import marshal
import os

hkk_file = "exemplo.hkk"
temp_dir = "cache.cache"

# Lê header e indicador
with open(hkk_file, "rb") as f:
    header = f.read(8)
    indicator = f.read(4)
    tar_bytes = f.read()

# Verifica header
if header != bytes([0x09, 0x90, 0x46, 0x57, 0x22, 0x56, 0x77, 0x19]):
    raise ValueError("Arquivo inválido!")

# Salva tar temporário
tar_path = os.path.join(temp_dir, "temp.tar.xz")
os.makedirs(temp_dir, exist_ok=True)
with open(tar_path, "wb") as f:
    f.write(tar_bytes)

# Extrai tar.xz
with tarfile.open(tar_path, "r:xz") as tar:
    tar.extractall(temp_dir, filter=lambda tarinfo, path: tarinfo)

# Executa o .pkk
pkk_file = os.path.join(temp_dir, "exemplo.pkk")
with open(pkk_file, "rb") as f:
    byte_code = f.read()

exec(marshal.loads(byte_code))