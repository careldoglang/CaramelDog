import random
import time

# --- CLASSES ---
class Personagem:
    def __init__(self, nome):
        self.nome = nome
        self.nivel = 1
        self.xp = 0
        self.hp_max = 100
        self.hp = self.hp_max
        self.forca = 10
        self.defesa = 5
        self.inventario = []
        self.ouro = 50

    def atacar(self, inimigo):
        dano = self.forca + random.randint(-2, 5) - inimigo.defesa
        dano = max(0, dano)
        inimigo.hp -= dano
        print(f"{self.nome} atacou {inimigo.nome} e causou {dano} de dano!")

    def ganhar_xp(self, quantidade):
        self.xp += quantidade
        print(f"{self.nome} ganhou {quantidade} XP!")
        if self.xp >= self.nivel * 50:
            self.nivel_up()

    def nivel_up(self):
        self.nivel += 1
        self.hp_max += 20
        self.hp = self.hp_max
        self.forca += 3
        self.defesa += 2
        self.xp = 0
        print(f"\n🎉 {self.nome} subiu para o nível {self.nivel}!\n")

class Inimigo:
    def __init__(self, nome, hp, forca, defesa, xp, ouro):
        self.nome = nome
        self.hp = hp
        self.forca = forca
        self.defesa = defesa
        self.xp = xp
        self.ouro = ouro

    def atacar(self, jogador):
        dano = self.forca + random.randint(-2, 3) - jogador.defesa
        dano = max(0, dano)
        jogador.hp -= dano
        print(f"{self.nome} atacou {jogador.nome} e causou {dano} de dano!")

class Item:
    def __init__(self, nome, tipo, valor):
        self.nome = nome
        self.tipo = tipo
        self.valor = valor

# --- LISTAS E DADOS ---
nomes_inimigos = [
    "Goblin", "Esqueleto", "Lobo", "Bandido", "Slime", "Orc", "Troll", "Morcego", 
    "Zumbi", "Aranha", "Mago Sombrio", "Golem", "Fantasma", "Vampiro", "Manticora",
    "Quimera", "Hidra", "Centauro", "Minotauro", "Ciclope", "Kobold", "Sátiro",
    "Liche", "Dragão", "Warg", "Demônio", "Espectro", "Basilisco", "Fenrir",
    "Medusa", "Moura", "Fada Negra", "Bruxa", "Lobo Fantasma", "Grifo", "Serpente",
    "Anjo Caído", "Cavaleiro Negro", "Samurai Sombrio", "Pirata Fantasma", "Ninja",
    "Gárgula", "Tarantula Gigante", "Cervo Sombrio", "Urso Mutante", "Tigre Fantasma",
    "Crocodilo", "Harpia", "Wendigo", "Zumbi Gigante"
]

itens_loja = [
    Item("Poção de HP", "cura", 20),
    Item("Espada de Ferro", "arma", 50),
    Item("Escudo de Madeira", "defesa", 40),
    Item("Elixir Mágico", "cura", 70),
    Item("Armadura de Aço", "defesa", 100)
]

# --- FUNÇÕES ---
def criar_inimigo(nivel_jogador):
    nome = random.choice(nomes_inimigos)
    hp = random.randint(20, 40) + nivel_jogador * 10
    forca = random.randint(5, 10) + nivel_jogador * 2
    defesa = random.randint(2, 5) + nivel_jogador
    xp = random.randint(20, 50) + nivel_jogador * 10
    ouro = random.randint(10, 50) + nivel_jogador * 5
    return Inimigo(nome, hp, forca, defesa, xp, ouro)

def batalha(jogador, inimigo):
    print(f"\n⚔️ Uma batalha começou! {jogador.nome} vs {inimigo.nome}\n")
    while jogador.hp > 0 and inimigo.hp > 0:
        jogador.atacar(inimigo)
        if inimigo.hp <= 0:
            print(f"{inimigo.nome} foi derrotado!\n")
            jogador.ganhar_xp(inimigo.xp)
            jogador.ouro += inimigo.ouro
            print(f"Você ganhou {inimigo.ouro} de ouro!")
            break
        time.sleep(1)
        inimigo.atacar(jogador)
        if jogador.hp <= 0:
            print(f"{jogador.nome} foi derrotado! 😢\n")
            break
        print(f"{jogador.nome} HP: {jogador.hp} | {inimigo.nome} HP: {inimigo.hp}\n")
        time.sleep(1)

def explorar(jogador):
    print("\n🌲 Você está explorando a floresta...")
    time.sleep(2)
    chance = random.random()
    if chance < 0.6:
        inimigo = criar_inimigo(jogador.nivel)
        batalha(jogador, inimigo)
    elif chance < 0.85:
        item = random.choice(itens_loja)
        jogador.inventario.append(item.nome)
        print(f"Você encontrou um {item.nome}!")
    else:
        ouro_achado = random.randint(10, 50)
        jogador.ouro += ouro_achado
        print(f"Você encontrou {ouro_achado} de ouro!")

def loja(jogador):
    print("\n🏪 Bem-vindo à Loja!")
    for i, item in enumerate(itens_loja, 1):
        print(f"{i} - {item.nome} ({item.tipo}) - {item.valor} ouro")
    print(f"Seu ouro: {jogador.ouro}")
    escolha = input("Escolha o número do item para comprar ou '0' para sair: ")
    if escolha.isdigit():
        escolha = int(escolha)
        if escolha == 0:
            return
        if 1 <= escolha <= len(itens_loja):
            item = itens_loja[escolha - 1]
            if jogador.ouro >= item.valor:
                jogador.ouro -= item.valor
                jogador.inventario.append(item.nome)
                print(f"Você comprou {item.nome}!")
            else:
                print("Você não tem ouro suficiente!")
        else:
            print("Escolha inválida!")

def mostrar_status(jogador):
    print(f"\n--- STATUS ---")
    print(f"Nome: {jogador.nome}")
    print(f"Nível: {jogador.nivel} | XP: {jogador.xp}/{jogador.nivel*50}")
    print(f"HP: {jogador.hp}/{jogador.hp_max}")
    print(f"Força: {jogador.forca} | Defesa: {jogador.defesa}")
    print(f"Ouro: {jogador.ouro}")
    print(f"Inventário: {jogador.inventario}")
    print("----------------\n")

# --- LOOP PRINCIPAL ---
def main():
    print("🎮 Bem-vindo ao RPG do Terminal - Versão Turbo! 🎮")
    nome = input("Digite o nome do seu herói: ")
    jogador = Personagem(nome)

    while True:
        mostrar_status(jogador)
        print("O que deseja fazer?")
        print("1 - Explorar")
        print("2 - Descansar (+50 HP)")
        print("3 - Visitar Loja")
        print("4 - Sair do jogo")
        escolha = input("> ")

        if escolha == "1":
            explorar(jogador)
        elif escolha == "2":
            jogador.hp = min(jogador.hp + 50, jogador.hp_max)
            print(f"{jogador.nome} descansou e recuperou HP!")
        elif escolha == "3":
            loja(jogador)
        elif escolha == "4":
            print("Saindo do jogo... Até a próxima aventura!")
            break
        else:
            print("Escolha inválida, tente novamente.")

if __name__ == "__main__":
    main()