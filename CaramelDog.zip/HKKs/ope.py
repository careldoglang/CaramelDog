import marshal
import tarfile
import io
import os

def run_hkk(hkk_file):
    with open(hkk_file, "rb") as f:
        data = f.read()

    header = data[:8]
    indicator = data[8:12]
    body = data[12:]

    # validação simples
    if header != bytes([0x09, 0x90, 0x46, 0x57, 0x22, 0x56, 0x77, 0x19]):
        raise ValueError("Arquivo inválido ou corrompido")

    file_like = io.BytesIO(body)
    with tarfile.open(fileobj=file_like, mode="r:xz") as tar:
        for member in tar.getmembers():
            if member.name.endswith(".pkk"):
                f = tar.extractfile(member)
                bytecode = f.read()
                break
        else:
            raise FileNotFoundError("Nenhum .pkk encontrado dentro do pacote")

    code_object = marshal.loads(bytecode)
    exec(code_object, globals(), globals())

if __name__ == "__main__":
    print("Mini-OS runner iniciado. CTRL+C para sair.")
    while True:
        # aqui você poderia, por exemplo, ler um diretório ou esperar input
        for arquivo in os.listdir("."):
            if arquivo.endswith(".hkk"):  # ou ".hz"
                try:
                    run_hkk(arquivo)
                except Exception as e:
                    print(f"Erro ao rodar {arquivo}: {e}")
        # evita loop 100% CPU
        import time
        time.sleep(1)